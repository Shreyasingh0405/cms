const commentModel = require("../models/schemas/commentSchema")
const mongoose = require("mongoose")
const createComment = async (req, res) => {
    try {
        const insertComment = req.body
        if (!mongoose.isValidObjectId(insertComment.creator)) {
            return res.send({ status: 0, msg: "invalid creatorId" })
        }
        if (!mongoose.isValidObjectId(insertComment.content)) {
            return res.send({ status: 0, msg: "invalid contentId" })
        }
        const checkingComment = await commentModel.create(insertComment)
        if (checkingComment.is_approved == true) {
            return res.send({ status: 1, msg: "comment post successfully", data: checkingComment })
        }return res.send({status:0,msg:"cannot post"})
    } catch (error) {
        return res.send(error.message)
    }

}
module.exports = { createComment }